# Flugan
News should be based on facts. Flugan identifies articles at https://omni.se that have a speculative title and transforms them to what they truly are - a smelly pile of s**t. Flugan also removes DOM objects that it confidently identifies as ads.
